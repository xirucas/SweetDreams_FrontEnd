import "./SobreNos.css"

export const SobreNos = () => {
    return(
        <>
        <h1>Sobre Nós</h1>
        </>
    )
}