import "./Contactos"

export const Contactos = () => {
    return(
        <>
        <h1>Contactos</h1>
        </>
    )
}