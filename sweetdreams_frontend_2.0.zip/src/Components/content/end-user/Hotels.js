import "./Hotels.css"
export const Hotels = (props) => {
    return(
      <div>
          
      </div>    
    )
  };
